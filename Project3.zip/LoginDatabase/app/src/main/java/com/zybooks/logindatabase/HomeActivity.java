package com.zybooks.logindatabase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import android.widget.Toolbar;

public class HomeActivity extends AppCompatActivity{
    String username;
    Button addButton, display;
    ImageButton iconAdd, editButton, deleteButton;

    EditText editWeight, editDate;
    private DBHandler dbHandler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        //find the all buttons and initialize all variables
        addButton = findViewById(R.id.button4);
        iconAdd = findViewById(R.id.imageButtonAdd);
        editButton = findViewById(R.id.imageButtonEdit);
        deleteButton = findViewById(R.id.imageButtonDelete);
        display = findViewById(R.id.buttonDisplay);

        //initialize edit text fields
        editWeight = findViewById(R.id.editTextText);
        editDate = findViewById(R.id.editTextText2);

        //creating a new dbhandler class
        //and passing our context to it
        dbHandler = new DBHandler(HomeActivity.this);

        //event handling for when the user clicks the display button
        display.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), DisplayWeights.class);
                startActivity(intent);
            }
        });
        //event handling for the add button
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //line to get data from edit text fields
                String weight_entry = editWeight.getText().toString();
                String date_entry = editDate.getText().toString();

                //validating entry for emptiness
                if(weight_entry.isEmpty() || date_entry.isEmpty()){
                    Toast.makeText(HomeActivity.this, "Please enter data in all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                //add to the sqlite database
                dbHandler.addNewWeights(weight_entry, date_entry);
                //display a toast for successfully adding to database
                Toast.makeText(HomeActivity.this, "Weight has been added to database", Toast.LENGTH_SHORT).show();

                //empty the entry fields
                editWeight.setText("");
                editDate.setText("");
            }
        });
        //event handler for the icon add button
        iconAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                startActivity(intent);
            }
        });

        //event handler for the edit button
        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), EditActivity.class);
                startActivity(intent);
            }
        });

        //event handler for delete button
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), DeleteActivity.class);
                startActivity(intent);
            }
        });
        //for setting SMS notification permissions
        Intent intent = getIntent();
        username = intent.getStringExtra("username");

        NotificationManager.initialize(getApplicationContext(), username);
    }
    //hook up to the menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.appbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item){
        int itemId = item.getItemId();
        //Determine which menu option was selected
        if(itemId == R.id.action_notification){
            //add selected
            Intent intent = new Intent(getApplicationContext(), NotificationActivity.class);
            startActivity(intent);
            return true;
        }
        else if(itemId == R.id.action_logout){
            //logout selected
            Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
