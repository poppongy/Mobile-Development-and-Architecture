package com.zybooks.logindatabase;

import static android.app.ProgressDialog.show;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class NotificationManager {
    private static SharedPreferences sharedPreferences;
    private static SharedPreferences.Editor editor;
    private static final String INFO = "notification_prefs";
    private static NotificationManager instance;
    private String username;

    //singleton constructor
    //context -- the context
    //username -- username for logged in user
    private NotificationManager(Context context, String username){
        this.username = username;
        sharedPreferences= context.getSharedPreferences(INFO, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        editor.apply();
    }
    /**
     * Initializating the notification manager
     * coontext -- the context
     * username -- the current username
     */

    public static void initialize(Context context, String username){
        if(instance == null){
            instance = new NotificationManager(context, username);
        }
    }
    /**
     * getting the singleton instance
     * throws an exception if instance has not been initialized
     * returns notificationMANGAGER instance
     */
    public static NotificationManager getInstance(){
        if(instance == null){
            throw new IllegalStateException("Notification manager has not been initialized");
        }return instance;
    }
    public void setUsername(String username){
        this.username = username;
    }
    public void saveNotificationPreference(boolean isEnabled ){
        editor.putBoolean(username, isEnabled);
        editor.apply();
    }
    public boolean getNotificationPreference(){
        return sharedPreferences.getBoolean(username, false);
    }
    public void removeNotificationPreference(){
        if(sharedPreferences.contains(username)){
            editor.remove(username);
            editor.apply();
        }
    }
}

