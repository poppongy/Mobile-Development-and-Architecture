package com.zybooks.logindatabase;

import android.os.Bundle;
import android.widget.Switch;

import androidx.appcompat.app.AppCompatActivity;

public class NotificationActivity extends AppCompatActivity {
    Switch aSwitch;
    NotificationManager notificationManager;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        //initialize switch
        Switch aswitch = (Switch) findViewById(R.id.simpleSwitch);

        //check current state of switch button
        boolean switchState = aswitch.isChecked();

        //pass state to shared preference manager
        notificationManager.saveNotificationPreference(switchState);
    }
}
