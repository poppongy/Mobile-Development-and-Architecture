package com.zybooks.logindatabase;

public class DisplayModal {
    //declaring attributes
    String weight;
    String date;
    int id;

    public DisplayModal(String weight, String date) {
        this.weight = weight;
        this.date = date;
    }

    //setting getters and setters
    public int getId(){
        return id;
    }
    public void setId(int new_id){
        this.id = new_id;
    }
    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
