package com.zybooks.logindatabase;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.core.view.WindowCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.zybooks.logindatabase.databinding.ActivityDeleteBinding;

public class DeleteActivity extends AppCompatActivity {

    Button delete, cancel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);

        delete = findViewById(R.id.ButtonDelete);
        cancel = findViewById(R.id.ButtonCancel);

        //event listeners for buttons
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //display toast confirming the deletion if successful
                Toast.makeText(DeleteActivity.this, "Please enter all the fields", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(getApplicationContext(), DisplayWeights.class);
                startActivity(intent);
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                startActivity(intent);
            }
        });
    }
}