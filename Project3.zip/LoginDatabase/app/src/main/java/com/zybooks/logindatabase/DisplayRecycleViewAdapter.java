package com.zybooks.logindatabase;



import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

    public class DisplayRecycleViewAdapter extends RecyclerView.Adapter<DisplayRecycleViewAdapter.ViewHolder> {

        // variable for our array list and context
        private ArrayList<DisplayModal> courseModalArrayList;
        private Context context;

        // constructor
        public DisplayRecycleViewAdapter(ArrayList<DisplayModal> courseModalArrayList, Context context) {
            this.courseModalArrayList = courseModalArrayList;
            this.context = context;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            // on below line we are inflating our layout
            // file for our recycler view items.
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_display_weights, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            // on below line we are setting data
            // to our views of recycler view item.
            DisplayModal modal = courseModalArrayList.get(position);
            holder.weightTV.setText(modal.getWeight());
            holder.dateTV.setText(modal.getDate());
        }

        @Override
        public int getItemCount() {
            // returning the size of our array list
            return courseModalArrayList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            // creating variables for our text views.
            private TextView weightTitleTV, weightTV, dateTV;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                // initializing our text views
                weightTitleTV = itemView.findViewById(R.id.idTVTitle);
                weightTV = itemView.findViewById(R.id.idTVDate);
                dateTV = itemView.findViewById(R.id.idTVDate);

            }
        }


}
